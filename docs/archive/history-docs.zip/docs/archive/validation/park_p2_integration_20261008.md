# park-p2-02 통합 검증 (2026-10-08)

## 범위

사용자 요청으로 기존 `park-p2-02` 작업을 최신 `main`에 통합한다.
원래 작업 폴더의 개인 Word 문서와 관리자 검증 JSON은 포함하지 않는다.
중앙 서버 배포, 에이전트 갱신, 추가 실제 수신 검증은 이번 요청 범위가 아니다.

통합 전 기준은 `park-p2-02`의 `384b6cef98b62045cbbbf2eaad8d0fcd95695cdf`와
PR #3 수정/병합을 포함한 `main`의 `5dd532a`이다.
다음 기존 커밋을 재작성하거나 squash하지 않고 보존한다.

| 커밋 | 범위 |
| --- | --- |
| ce260d7 | P2-02 저장량 계측·스냅샷 검증 도구 |
| 4d6338e | 균형형 백업 준비·소스별 저장량 검증 |
| 0d5b96f | Linux·Packetbeat 수집 품질 계측 |
| 384b6ce | Windows 지연 자동 시작·부팅 수집 안정화 검증 |

## 충돌 해결과 보존

- `docs/work_tracker.md`: 양쪽 작업 기록 및 완료/미완료 이력을 모두 유지했다.
- `deploy/agents/tests/bundle-windows.ps1`: 호스트 모의 처리 전 모듈 로딩과 현재 PowerShell 셸의 보안 모듈 경로 지정 모두 유지했다.
- `.github/workflows/ci.yaml`: 기존 CI를 유지하고 Windows에 P2 저장량/백업 준비/계측 시험을 추가했다.
- `app.py`, `privacy.py`, Linux 운영 파서, 사건/경보 조회 권한 및 서버 Dockerfile은 최신 main과 동일하다. PR #3의 입력 자료형·담당자 유지·분석가 접근 수정도 보존했다.
- 수집 품질 화면은 main의 인증·공통 탐색을 유지하면서 호스트/네트워크 통계를 분리한다.

새 코드나 다른 브랜치로 전체 파일을 덮어쓰지 않았다. GitHub에는 원래 브랜치 이름
`park-p2-02`로 푸시하고 merge 방식의 PR로 기존 커밋 이력을 보존한다.

## 로컬 검증

| 검증 | 결과 |
| --- | --- |
| 전체 Python | 544 통과, 14 생략, 239 subtests 통과 |
| 화면 Node 시험 | 98 통과 |
| 에이전트 Node 직렬 시험 | 101 통과, 1 생략, 실패 0 |
| Windows PowerShell 5.1 문법 | 에이전트 스크립트 36개 통과 |
| Ruff `src tests tools` | 통과 |
| Bandit 중간/높음 검사 | 통과 |
| 오프라인 탐지 프로필 | AUTH·AWS·OCI·sequence 6개 유효, 저장 없음 |
| 실제 PR 변경 기준 공백 검사 | 통과 |

시험 환경은 Windows, Python 3.13 전용 가상환경 및 Node 24이다.
원격 CI는 Python 3.12/Node 22의 Ubuntu·Windows를 별도로 검사한다.

최초 Python 시험은 543 통과/1 실패였다. 개인 프로필 아래의 관리형 worktree에
만든 로그 fixture가 제품의 개인 파일 수집 금지 정책에 거절된 것이 원인이었다.
`SOC_TEST_P2_METRICS_DIR`로 시험 전용 scratch를 프로필 밖에 지정한 뒤 전체 시험이
통과했다. 제품의 금지 경로·개인정보 정책은 바꾸지 않았다.
에이전트 시험의 자식 Windows PowerShell이 자체 모듈 경로를 사용하도록 이번 시험
프로세스의 `PSModulePath`만 비웠다. 전역 실행 정책·서비스·키는 바꾸지 않았다.
Ruff가 발견한 사용하지 않는 시험 import도 제거했다.

## 남은 제한

- 원격 CI 및 PR 병합은 아래 결과처럼 완료했다. 운영 배포와는 구분한다.
- 이번에 통합한 소스를 중앙 서버/새 ZIP에 배포하거나 실제 에이전트 수신을 재검증하지 않았다. 과거 실제 VM 검증 기록과 구분한다.
- P2-02의 독립 백업 저장소 연결은 계속 보류한다. 검토용 보고서가 운영 백업 성공이나 자동 보존 적용을 뜻하지 않는다.
- P2-03의 정식 통합 소스 배포 및 과거 Linux 상태 spool 조사는 아직 미완료다.
- OCI 연결이나 실제 클라우드 시험은 하지 않았다. 오프라인 규칙 검증은 실제 OCI 수집 검증이 아니다.
- 기존 main의 보관용 patch 문서는 변경하지 않았다. 공백 검사 기준은 실제 PR 차이인 `origin/main`이다.

## 원격 완료

- [PR #4](https://github.com/Gandalem/cloud-soc/pull/4): `park-p2-02` → `main`, merge 방식으로 병합 완료.
- 검증한 head: `051f3b46ae67922380c96d2da21b831a2c321e5d`.
- [Ubuntu CI](https://github.com/Gandalem/cloud-soc/actions/runs/37726452853/job/113145609162): success. 전체 회귀·보안/의존성 검사·Compose 검증·서버 이미지 빌드 포함.
- [Windows CI](https://github.com/Gandalem/cloud-soc/actions/runs/37726452853/job/113145608789): success. P2 시험·에이전트 설치/복구·화면 회귀 포함.
- 병합 커밋: `ef8d9a7813bdab6a80f1874225cf7a6646a8941d`.
- 완료 기록 커밋은 이 문서와 작업 목록만 변경한다. 테스트한 제품 코드와 원격 병합 코드가 동일하며 운영 배포/수신 완료를 주장하지 않는다.
- 기존 Actions의 Node 20 런타임 폐기 경고는 후속 CI 유지보수가 필요하다. 이번 두 검사의 결과는 성공이다.
