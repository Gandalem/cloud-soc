# 증분 탐지 운영 배포 인수

2026-10-13 현재 중앙192.168.32.60의 정규화/기본 AUTH·early worker는3b9aff9/40ed90fb…를 유지합니다. 포털은 LAN 보완 뒤 상태 안내/개인 대시보드 후속517178d를 적용한04daf08f…입니다. [최신 통합 점검·사건 저장/재시작·실제 이미지·보호/복구·제한](cloud_soc_issue_audit_20261013.md)을 먼저 대조하세요. 활성 override는 state/early-release-000659f/early.override.json입니다. 서버 Git HEAD92d13c0·포털 patch·worker 소스를 동일 버전으로 가정하지 않습니다. [기존 AUTH 인수](early_deployment_validation_20261013.md)와 아래 날짜별 이력은 보존합니다.

## 현재 읽기 점검과 최소 권한 유지

검증한 새 `deploy/server/runtime-audit.py`는 정확한 workspace/project의 기존6개 컨테이너와 활성 Compose 파일 해시·시작/프로필을 읽습니다. 비밀 환경·전체 argv는 출력하지 않으며 label을 전체 소스 일치로 해석하지 않습니다. 현재 서버에는 새 코드가 checkout에 자동 반영되지 않았으므로 보호한 `state/audit-stability-20261013/release-ui` 안의 도구 또는 별도 검증된 소스/환경을 사용합니다.

```sh
sudo python3 /home/kopo/cloud-soc/state/audit-stability-20261013/release-ui/deploy/server/runtime-audit.py --workspace /home/kopo/cloud-soc
```

`deploy/server/reader-history.py`는 기본값이 **읽기 계획 출력**입니다. 검증된 Python/Elasticsearch 환경에서 현재 보호 CA·승인된 관리자 password 파일을 인수로 지정합니다. `--apply`는 별도 승인한 계획의 `--expected-before-sha256`이 현재 역할과 같을 때만 exact 두 history의 read/view_index_metadata를 덧붙입니다. 다른 사용자/비밀번호/키는 변경하지 않습니다. DLS/FLS와 미지원 정책은 수동 검토 대상으로 거부합니다. 적용 전 보호 백업·다른 관리자와 동시 역할 수정이 없음을 확인하고 결과를 읽기 대조합니다. 서비스 정상화만을 목적으로 기존 setup 전체 역할 쓰기를 재실행하지 않습니다.

현재 포털 보호 rollback은 최신 `portal-before-ui-followup`의 설정·이미지와 대조한 뒤 **portal image만** 기존 `cloud-soc:audit-e301783769b6`으로 되돌리고 동일 base/env/override의 `up -d --no-deps --no-build portal`을 사용합니다. 사용자 새 사건/메모·대시보드·DB/WAL/queue는 현재 값을 유지합니다. 최초 cases0 백업을 덮어써 새 사건을 잃지 않도록 합니다. 전체 Compose·ES/Kibana·worker 재시작이나 기존 start/floor/900초 유예/키/CA 변경은 이 포털 rollback에 포함하지 않습니다.

선택 통지/메타데이터 후보의 [구조·필드 gate·전환 조건](realtime_detection_20261013.md)을 참고합니다. 기존 start/source/profile/lateness/main state를 유지하고 notice mapping·별도 create_doc/read 권한·쌍 DB backup 후 명시 --early-auth로 켭니다. --include-patterns는 identity 변경이며 승인된 새 state/start와 인수가 필요합니다. Windows/웹/flow/AWS 후보와 SSH 다수 계정 프로필은 이번 시험에서 활성화하지 않았습니다. ES snapshot은 현재 repository/path.repo 미설정으로 미실행이며 원본을 변경하지 않는 승인 범위와 독립 복구 잔여를 구분합니다.

2026-10-12 최신 지정 VMware 결과: Ubuntu 192.168.235.128의 실제 SSH 실패 10회→AUTH-001 경보 1건·근거 10건·홈/개인 대시보드 표시와 실패 9회→경보 0건을 검증했습니다. [결과·제한](archive/validation/live_auth_validation_20261012.md). 아래 학교 환경과 2026-10-04 준비 기록은 당시 이력입니다.

현재 VMware의 활성 처리 구성은 서버 `state/live-auth-20261012/drift/compose.active.json`에 보존합니다. 원래 시작점·상태 파일·키·900초 유예 및 새 SSH 형식의 수신 시작 시각을 유지해야 합니다. 과거 Compose 명령으로 일괄 `up`하면 시험 서버의 최신 이미지/고정 옵션을 되돌릴 수 있으므로 먼저 실행 이미지·명령을 대조합니다. 후보 소스는 미커밋 패치이며 Git HEAD만으로 현재 실행 코드 전체를 나타내지 않습니다. 같은 VM 보호 백업은 P2-02의 독립 복구 저장소 완료를 뜻하지 않습니다.

2026-10-04: 사용자 운영 배포·기존 데이터 전환·실제 ES 검증 승인. 운영 접속은 미확보이며 아래 단계는 실행 결과가 아닌 준비 절차다.

## 현재 접속 상태

이전 기록의 중앙 Ubuntu 서버는 192.168.32.60, 계정 kopo, /home/kopo/cloud-soc다. 이번 환경에서 TCP 22는 4초 연결 시간 초과였다. SSH 설정/기존 등록 키가 발견되지 않았다. 현재 주소·인증 경로·신뢰한 SSH 지문을 확인한 뒤 재개한다. 개인키/비밀번호는 채팅·로그·패키지에 넣지 않는다.

## 실행 순서

1. 고정 SSH 지문, sudo 가능 여부, 실제 Compose 경로·실행 이미지·Git/배포 소스 차이, CA, ES 버전/상태, 디스크 여유, 현재 normalizer/detector/portal 상태를 확인한다. 기존 미커밋 운영 소스는 그대로 보호한다.
2. preflight-detection.py로 실제 ES 인덱스 수·필드 누락·기간·snapshot repository를 읽기 전용 검사한다. 이 도구는 저장소 존재만 확인하며 백업의 완료/복원 가능성을 인증하지 않는다.
3. 포털 DB 온라인 백업/verify, 중지 시점 백업, 기존 이미지/env/SQLite 처리 상태를 보호한다. ES snapshot을 생성하고 SUCCESS·실패 shard 0을 확인한다. 저장소 없으면 실제 서버 지원 경로에 맞춰 구성한다. VM 내부 백업과 외부 장애 복구 백업은 구분한다.
4. normalizer/detector를 중지하고 처리 체크포인트·정규화 문서·경보/근거 참조·사건 자료의 기준 건수/해시를 확보한다. 에이전트와 원본 수집 경로는 유지한다.
5. 기존 정규화 문서를 직접 update_by_query로 수정하지 않는다. normalized_at 추가가 기존 경보의 event_hash를 바꿀 수 있으므로 원본 및 정규화 증거는 보존한다. 실제 자료 확인 후 별도 이행 인덱스 또는 처리 기록 기반 수신 목록으로 전환한다. 새 참조/이전 참조를 모두 조회할 수 있어야 하며 과거 경보 중복, 재평가 시간 범위를 검증한다. 전체 역사 자료를 --accept-legacy-exclusion으로 제외하는 것은 사용자 요청의 데이터 전환 완료로 인정하지 않는다.
6. 이전 상태와 새 상태를 분리해 제한 키로 shadow 실행한다. 정상/임계값/배치 경계/재시작/지연/저장 실패·복구와 create-only·원본 쓰기 금지를 실제 ES에서 확인한다. 합성 이벤트는 운영 원본과 분리한 시험 조직/전용 인덱스에서 수행하며 기존 정상 운영 소스를 공격 시험 대상으로 사용하지 않는다.
7. 새 이미지와 필요한 매핑/역할만 준비하고 포털·normalizer·detector를 순차 교체한다. 같은 소스의 탐지기를 서로 다른 상태 파일로 동시에 가동하지 않는다.
8. 실제 신규 수집부터 정규화→탐지→경보 근거 조회까지 확인한다. detector 재시작 후 상태/동일 경보 ID/중복 없음을 확인하고 운영 화면 실패·stale·지연 표시도 대조한다.
9. 운영 체크포인트가 진행하고 기존 사건/패키지/키 이력 및 ES/Kibana/gateway/에이전트가 유지됨을 확인한다. 실패하면 새 처리기를 중지하고 보존한 이미지/env로 복구한다. ES/SQLite 상태는 임의 되감지 않고 재처리 영향 검토 후 복원한다.

## 사전 점검 명령 예시

### 대량 입력 재개 (2026-10-12)

정규화는 concrete index를 인코딩된 이름 기준 최대 3,000바이트씩 나누고 전체 매핑 검사 후 조회합니다. 부분 조회나 저장 실패 시 기존 체크포인트를 유지하며 원본/정규화 문서를 덮어쓰지 않습니다. 전체 실행당 페이지 제한은 유지합니다.

증분 탐지의 `--max-documents`(기본 20,000)는 이제 실행당 **새 입력 읽기 예산**입니다. 예산을 소진하면 SQLite의 `input_scan`/`input_hits`에 입력과 페이지 위치를 저장하고 다음 회차에서 이어 읽습니다. 상태는 `running`, 오류 표시는 `input_scan_pending`, `counts.input_pending`은 저장된 입력 수이며 경보 수가 아닙니다. `--once`가 정상 종료돼도 이 상태라면 구간 전체 탐지는 아직 완료되지 않았습니다. 전체 구간을 읽은 뒤에만 기존 탐지 순서·경보 생성·frontier/checkpoint를 확정합니다. 같은 수신 시각에 몰린 로그도 시간으로 잘라 버리지 않습니다.

재시작은 같은 상태 파일·시작점·소스·규칙 옵션을 사용합니다. PIT가 만료되면 같은 고정 구간을 다시 열고 저장한 문서 ID를 제외해 이어갑니다. 동일 ID의 정규화 문서가 불변이라는 기존 create-only 계약과 15분 수신 겹침 범위가 전제입니다. 과거 정규화 문서를 임의로 수정/삭제하면 완전성을 보장하지 않습니다. SQLite는 입력 메타데이터를 보관하므로 디스크 여유와 보호 권한을 확인하고, 실행 중 DB/WAL을 개별 복사하거나 임의로 지우지 않습니다.

`--max-active-events`(기본 20,000)는 별도의 pending/상관 시간창 상태 상한입니다. `active_state_limit`이면 입력과 체크포인트를 보존한 채 실패합니다. 원인·자원 사용량을 확인한 후 승인된 용량으로 이 옵션만 조정해 같은 상태에서 재개할 수 있습니다(최대 1,000,000). 자동 상향이나 이벤트 삭제는 하지 않습니다. 입력 spool은 최대 1,000,000건, 문서당 256KiB이며 초과 시 `input_spool_limit`/`input_document_size_limit`로 실패합니다. 이는 운영 용량 제한이며 고속 지속 유입의 처리량 보장이나 무제한 메모리 사용 허용이 아닙니다. `--snapshot`에는 기존 전체 조회 상한을 그대로 적용합니다.

서버의 실제 경로로 대체한다. 관리자 비밀번호는 파일로만 읽고 결과에는 이벤트 본문/자격 증명이 없다.

```sh
python3 deploy/server/preflight-detection.py \
  --es-url https://localhost:9200 --ca-file state/server/tls/ca.crt \
  --password-file state/server/secrets/elastic_password \
  --report state/verification/detection-preflight-20261004.json
```

Python Elasticsearch 의존성이 있는 보호 실행 환경에서 수행한다. code 2는 백업/클러스터 조건 미충족이며 자동 배포하지 않는다.
